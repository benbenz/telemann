module.exports = require('./lib/tokenfield').default;
